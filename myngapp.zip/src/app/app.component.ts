import { Component } from '@angular/core';

//Component Directive 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent {
  title: string = 'myNgApp';
  displayElement: boolean = true;
  switchNumber: number = 3;
  dataElem: Array<object> = [{
    name: 'arvin',
    id: 167807
  }, {
    name: 'foo',
    id: 666677
  }, {
    name: 'bar',
    id: 12345
  }]

  isItalic: boolean = false
  myStyle(){
    let styles= {
      'font-weight' : 'bold',
      // tertinary operator
      'font-style' : this.isItalic ? 'italic': 'normal',
      'font-size' : '20px'
    }
    console.log(document.getElementById("demoDiv"));//JS way
    return styles;
  }

  //Custom Directive TODO
  //ng generate directive changeColor(created by me)

  //new component
  //ng generate component parent
  //ng g c child - short way

  //install bootstrap 
  //npm i bootstrap --save // --save is to add to dependency in package.json

 //guard service for routing
//canActivate - check whether user is authorised to navigate
//canActivatechild - checks whether child can be loaded
//Resolve - promise
//Canload - lazy 
//Can deactive - source route

}
