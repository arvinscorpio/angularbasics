import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.sass']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;
  isSubmitted: boolean = false;
  constructor(private formBuilder: FormBuilder) {//dependency injection

  }

  ngOnInit() {
    this.registerForm = this.formBuilder.group({
      firstName: ['', Validators.required],
      userName: ['', Validators.required],
      phoneNumber: ['', Validators.required],
      email: ['', [Validators.required, Validators.email]]
    })
  }

  onSubmit(){
    console.log('form submitted');
    console.log(this.registerForm);
    this.isSubmitted = true;
    if(this.registerForm.valid){

    } else {

    }
  }

}
