import { Component, OnInit, Input, Output,EventEmitter } from '@angular/core';


@Component({
  selector: 'app-child',
  templateUrl: './child.component.html',
  styleUrls: ['./child.component.sass']
})
export class ChildComponent implements OnInit {

  //input, output Decorator - exchange data between parent and child
  @Input() foo: string;// get data from parent by direct passing it
  @Output() sendData = new EventEmitter();// send back to parent via callback
  constructor() {
    console.log(this.foo);
   }

  ngOnInit() {
  }

  handleClick(){
    //send data from child to parent
    //callbacks -> emit
    this.sendData.emit('data from child');
  }

}
