import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-employees',
  templateUrl: './employees.component.html',
  styleUrls: ['./employees.component.sass']
})
export class EmployeesComponent implements OnInit {

  employeesList: Array<object>;
  constructor() { }

  ngOnInit() {
    this.employeesList = [
      {
        name: 'arvin',
        id: 1
      },
      {
        name: 'vin',
        id: 2
      },
      {
        name: 'ain',
        id: 3
      },
      {
        name: 'ssin',
        id: 4
      },
      {
        name: 'niv',
        id: 5
      }

    ]
  }

}
