import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-parent',
  templateUrl: './parent.component.html',
  styleUrls: ['./parent.component.sass']
})
export class ParentComponent implements OnInit {

  sendToChild: string = 'random text from parent';
  childData: string;
  constructor() { }

  ngOnInit() { // lifeccyle func which is called when component loaded before constructor
  }

  getData(data: string)
  {
    this.childData = data;
  }

}
