import { Directive, ElementRef } from '@angular/core';

@Directive({
  selector: '[appChangeColor]'
})
export class ChangeColorDirective {

  constructor(private elem: ElementRef) {//dependency injection
    console.log('directive');
    console.log(elem);
    console.log(elem.nativeElement);
    elem.nativeElement.style.backgroundColor = 'red';
    elem.nativeElement.style.fontSize = '22px';
   }

}
