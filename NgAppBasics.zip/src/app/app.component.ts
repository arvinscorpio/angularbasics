import { Component } from '@angular/core';

//Component Directive 
@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.sass']
})
export class AppComponent {
  title: string = 'myNgApp';
  displayElement: boolean = true;
  switchNumber: number = 3;
  dataElem: Array<object> = [{
    name: 'arvin',
    id: 167807
  }, {
    name: 'foo',
    id: 666677
  }, {
    name: 'bar',
    id: 12345
  }]

  isItalic: boolean = false
  myStyle(){
    let styles= {
      'font-weight' : 'bold',
      // tertinary operator
      'font-style' : this.isItalic ? 'italic': 'normal',
      'font-size' : '20px'
    }
    console.log(document.getElementById("demoDiv"));//JS way
    return styles;
  }

  //Custom Directive TODO
  //ng generate directive changeColor(created by me)

  //new component
  //ng generate component parent
  //ng g c child - short way

  //install bootstrap 
  //npm i bootstrap --save // --save is to add to dependency in package.json

 //guard service for routing
//canActivate - check whether user is authorised to navigate - destination route
//canActivateChild - checks whether child can be loaded
//Resolve - promise and so on
//Canload - lazy loading
//Can deactive - source route - user is authorise to leave the route

//create gurad auth
//ng g guard auth

//create a service
//ng g s auth

//html5 storages
//local, session or cache -- to iew - f12-->applicaiton and list

//line1
//line 2
//line 3( async - promise(success, failure))
//line 4
//line 5
//create a interface 
//ng g interface posts

//install angular libraries if not present
//npm install @angular/http@latest
}
