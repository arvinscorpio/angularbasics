import { NgModule, Component } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';

import {EmployeeComponent} from './employee/employee.component';
import {EmployeesComponent} from './employees/employees.component';
import { RegisterComponent } from './register/register.component';
import { AuthGuard } from './auth.guard';

const routes: Routes = [

  {
    path:'register',
    pathMatch:'full',
    component: RegisterComponent
  },
  {
    path:'employeees',
    component: EmployeesComponent,
    canActivate: [AuthGuard]
  },
  {
    path:'employee/:id',
    component:EmployeeComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
