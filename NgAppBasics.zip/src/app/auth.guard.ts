import { Injectable } from '@angular/core';
import { CanActivate, ActivatedRouteSnapshot, RouterStateSnapshot, UrlTree } from '@angular/router';
import { Observable } from 'rxjs';
import {AuthService} from './auth.service'

@Injectable({
  providedIn: 'root'
})
export class AuthGuard implements CanActivate {// extended from parent CanActiviate class

  constructor(private auth:AuthService){

  }
  canActivate(){
    //create a serivce and check with values from that service
    if(this.auth.getToken() === 'VALID'){ //=== checks type and value , == checks only the value
     return true;// authorised to view a particular route
    } else{
      //return to register/login page
      alert('not authorised');
    return false;
    }
  }
}
