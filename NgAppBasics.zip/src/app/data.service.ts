import { Injectable } from '@angular/core';
import { Http, Response } from '@angular/http';
import { Observable } from 'rxjs/internal/observable';
//import 'rxjs/add/operator/map';
import { map } from 'rxjs/operators';
import { HttpClient } from '@angular/common/http';

import { Posts } from './posts';
//import 'rxjs/Rx';


@Injectable({
  providedIn: 'root'
})
export class DataService {

  //constructor(private http: Http) { }
  constructor(private http: HttpClient) { }

  //getPosts(): Observable<Posts[]> {
    //GET
    //return this.http.get('https://jsonplaceholder.typicode.com/posts')
    //.map((respose: Response) => {
      //  return <Posts[]>respose.json();
      //})

      
   
 // }

  // getPosts() : Observable<Posts[]> {
  //   this.http.get('https://jsonplaceholder.typicode.com/posts').pipe(map(data => {})).subscribe(respose => {
  //     return <Posts[]>respose.json();
  //   });


//     import { map } from 'rxjs/operators';
// import { HttpClient } from '@angular/common/http';

// // ...
// export class MyComponent {
//   constructor(private http: HttpClient) { }
//   getItems() {
//     this.http.get('https://example.com/api/items').pipe(map(data => {})).subscribe(result => {
//       console.log(result);
//     });
 // }

}
