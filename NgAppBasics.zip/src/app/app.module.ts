import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { ReactiveFormsModule} from '@angular/forms'
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { ChangeColorDirective } from './change-color.directive';
import { ParentComponent } from './parent/parent.component';
import { ChildComponent } from './child/child.component';
import { RegisterComponent } from './register/register.component';
import { EmployeeComponent } from './employee/employee.component';
import { EmployeesComponent } from './employees/employees.component';

import {AuthService} from './auth.service';
import {AuthGuard} from './auth.guard';

@NgModule({
  declarations: [// component/directives etc decalrations which we have crearted
    AppComponent,
    ChangeColorDirective,
    ParentComponent,
    ChildComponent,
    RegisterComponent,
    EmployeeComponent,
    EmployeesComponent
  ],
  imports: [//importing from angular
    BrowserModule,
    AppRoutingModule,
    ReactiveFormsModule
  ],
  providers: [AuthService, AuthGuard],//used to load the serivce with injectable
  bootstrap: [AppComponent]
})
export class AppModule { }
